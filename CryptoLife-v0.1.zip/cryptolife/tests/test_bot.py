import math
import tempfile
import unittest
from pathlib import Path
from bot import Wallet, locked, load, save


class WalletTests(unittest.TestCase):
    def test_no_borrowing_and_trading_costs(self):
        w = Wallet(price=100)
        w.buy()
        self.assertEqual(w.cash, 75)
        self.assertLess(w.units, .25)
        w.sell("test")
        self.assertLess(w.cash, 100)
        self.assertGreater(w.cash, 99)
        self.assertEqual(w.units, 0)

    def test_duplicate_quotes_and_invalid_prices(self):
        w = Wallet()
        self.assertTrue(w.tick(100, 1000))
        self.assertFalse(w.tick(200, 1000))
        self.assertEqual(w.price, 100)
        for bad in (0, -1, math.nan, math.inf):
            with self.assertRaises(ValueError):
                w.tick(bad, 1001)
        self.assertEqual(w.price, 100)

    def test_death_is_permanent_after_recovery(self):
        w = Wallet(cash=0, units=.01, price=100)
        w.tick(100, 1000)
        self.assertEqual(w.status, "DEAD")
        self.assertEqual(w.units, 0)
        w.tick(100000, 1001)
        w.buy()
        self.assertEqual(w.status, "DEAD")
        self.assertEqual(w.units, 0)

    def test_drawdown_liquidates_and_pauses(self):
        w = Wallet(cash=0, units=1, price=100)
        w.tick(70, 1000)
        self.assertEqual(w.status, "PAUSED")
        self.assertEqual(w.units, 0)

    def test_profit_withdrawal_preserves_capital(self):
        w = Wallet(cash=150, price=100, high_water=150)
        w.withdraw(30)
        self.assertEqual(w.cash, 120)
        self.assertEqual(w.withdrawn, 30)
        self.assertEqual(w.status, "ALIVE")
        with self.assertRaises(ValueError):
            w.withdraw(21)
        self.assertEqual(w.cash, 120)
        w.withdraw(20)
        with self.assertRaises(ValueError):
            w.withdraw(.01)

    def test_withdrawal_liquidates_if_needed(self):
        w = Wallet(cash=0, units=2, price=100, high_water=200)
        w.withdraw(30)
        self.assertEqual(w.units, 0)
        self.assertGreater(w.cash, 100)
        self.assertEqual(w.withdrawn, 30)

    def test_lock_and_persistence(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/"wallet.json"
            with locked(path):
                save(path, Wallet(status="DEAD"))
                with self.assertRaises(ValueError):
                    with locked(path):
                        pass
            self.assertEqual(load(path).status, "DEAD")
            self.assertFalse(Path(str(path)+".lock").exists())

    def test_strategy_requires_warmup(self):
        w = Wallet()
        for i in range(29):
            w.tick(100+i, 1000+i)
        self.assertEqual(w.units, 0)
        w.tick(129, 1029)
        self.assertGreater(w.units, 0)
        self.assertGreaterEqual(w.cash, 0)


if __name__ == "__main__":
    unittest.main()
